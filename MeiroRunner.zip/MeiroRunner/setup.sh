#!/bin/bash

echo "###############################################################################"
echo "Workshop environment setup starting.."
echo "###############################################################################"
echo "Do sanity check first..."

if [ -e ~/environment/roboMakerSettings.json ]; then
    echo "Ok."
else
    echo "Error!"
    echo "  It seems you are not in AWS RoboMaker developer environment now.."
    echo "  Please execute this on AWS RoboMaker developer environment."
    echo ""
    exit 1
fi

sudo apt-get update
source /opt/ros/$ROS_DISTRO/setup.sh
rosdep update

sudo pip3 install -U awscli
sudo pip3 install -U colcon-common-extensions colcon-ros-bundle
sudo pip3 install boto3

python3 ./setup_ws.py
