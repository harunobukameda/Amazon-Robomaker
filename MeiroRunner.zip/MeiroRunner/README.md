# Meiro Runner - Find the way to get out from the maze world by training a reinforcement learning model on AWS RoboMaker

Technologies for autonomous robots and self-driving cars have been rapidly advancing. Their development often relies on building application-specific simulation environments, and using the information to train reinforcement learning (RL) models. 

The following figure (a screenshot from Gazebo) shows you a simulation environment on AWS RoboMaker. This sample robot operating system (ROS) app sets up the environment where an agent is placed in a simple maze. Some of you might be curious about what meiro means? Meiro stands for a maze in Japanese. 

![image1](docs/images/image1.png)

An RL algorithm will help navigate the agent to reach to the GOAL without bumping into a wall. The agent has a 360-degree surround lidar scanner (360 points x 5 fps) so that it monitors the distance from the surrounding walls all around. The lidar data are used to describe a state at a given step within an episode. The agent makes a decision out of 5 different actions i.e. turn left, turn right, move straight, steer to the left, and steer to the right. (To learn more about the reinforcement learning framework used for this application, Coach, please take a look at the following [link](https://github.com/NervanaSystems/coach))  

## Preparation 

This application is expected to be executed through [AWS RoboMaker](https://aws.amazon.com/robomaker/).

On AWS RoboMaker development environment, execute follow to prepare the environment.

```
cd ~/environment
git clone https://github.com/xyz/meirorunner.git  meirorunner
cd meirorunner
./setup.sh
```

For further detail, please refer link(TODO)
